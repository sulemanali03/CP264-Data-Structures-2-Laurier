/**
 * -------------------------------------
 * @file  main.c
 * Assignment 1 Main Source Code File
 * -------------------------------------
 * @author Suleman Ali, 169044667, alix4667@mylaurier.ca
 *
 * @version 2023-09-07
 *
 * -------------------------------------
 */
#include <stdio.h>
#include "functions.h"

int main() {
	setbuf(stdout, NULL);

	// Testing each function
	printf("Feet to Acres: %.2f acres\n", feet_to_acres(100000)); // Expected: ~2.30
	printf("Mow Lawn: %d minutes\n", mow_lawn(10.0, 10.0, 5.0)); // Expected: 20 minutes
	printf("Date Convert: %d\n", date_convert(25101962)); // Expected: 19621025
	printf("Falling Time: %d seconds\n", falling_time(50)); // Expected: ~3 seconds
	printf("Hypotenuse: %.2f\n", hypotenuse(3.0, 4.0)); // Expected: 5.00
	printf("Sum Even: %d\n", sum_even(100)); // Expected: 2550
	printf("Partial Harmonic Sum: %.6f\n", sum_partial_harmonic(4)); // Expected: ~2.083333
	printf("Population Growth: %d years\n", population_growth(10, 10.0, 100)); // Expected: ~29 years

	return 0;
}
