/**
 * -------------------------------------
 * @file  movie_utilities.c
 * Assignment 2 movie_utilities Source Code File
 * -------------------------------------
 * @author
 *
 * @version 2024-09-13
 *
 * -------------------------------------
 */
#include "movie_utilities.h"

#include <stdio.h>
#include <string.h>
#include "movie_utilities.h"

void get_movie(movie_struct *source) {
	char title[MAX_STRING], director[MAX_STRING];
	int year, genre;
	float rating;

	printf("Title: ");
	fgets(title, MAX_STRING, stdin);
	title[strcspn(title, "\n")] = 0; // Remove trailing newline

	printf("Year: ");
	scanf("%d", &year);

	getchar(); // To consume the newline character left by scanf
	printf("Director: ");
	fgets(director, MAX_STRING, stdin);
	director[strcspn(director, "\n")] = 0;

	genres_menu();
	printf("Genre: ");
	scanf("%d", &genre);

	printf("Rating: ");
	scanf("%f", &rating);

	movie_init(source, title, year, director, genre, rating);
}

void read_movie(movie_struct *source, const char *line) {
	char title[MAX_STRING], director[MAX_STRING];
	int year, genre;
	float rating;

	sscanf(line, "%[^|]|%d|%[^|]|%f|%d", title, &year, director, &rating,
			&genre);
	movie_init(source, title, year, director, genre, rating);
}

