/**
 * -------------------------------------
 * @file  movie.c
 * Assignment 2 movie Source Code File
 * -------------------------------------
 * @author
 *
 * @version 2024-09-13
 *
 * -------------------------------------
 */
#include "movie.h"

// Array of strings for movie genres.
const char *const GENRES[] = { "science fiction", "fantasy", "drama", "romance",
		"comedy", "zombie", "action", "historical", "horror", "war", "mystery" };

// Calculates size of GENRES array.
const int GENRES_COUNT = sizeof GENRES / sizeof *GENRES;

void movie_init(movie_struct *source, const char *title, int year,
		const char *director, int genre, float rating) {
	assert(year >= FIRST_YEAR); // Validate the year
	assert(rating >= MIN_RATING && rating <= MAX_RATING); // Validate rating
	assert(genre >= 0 && genre < GENRES_COUNT); // Validate genre index

	strncpy(source->title, title, MAX_STRING - 1); // Copy title
	source->title[MAX_STRING - 1] = '\0'; // Ensure null termination

	strncpy(source->director, director, MAX_STRING - 1); // Copy director
	source->director[MAX_STRING - 1] = '\0'; // Ensure null termination

	source->year = year;
	source->genre = genre;
	source->rating = rating;
}

void movie_copy(const movie_struct *source, movie_struct *target) {
	strncpy(target->title, source->title, MAX_STRING - 1);
	target->title[MAX_STRING - 1] = '\0';

	strncpy(target->director, source->director, MAX_STRING - 1);
	target->director[MAX_STRING - 1] = '\0';

	target->year = source->year;
	target->genre = source->genre;
	target->rating = source->rating;
}

int movie_compare(const movie_struct *source, const movie_struct *target) {
	int title_cmp = strcmp(source->title, target->title);
	if (title_cmp != 0) {
		return title_cmp; // If titles are different, return comparison result
	}
	return source->year - target->year; // Otherwise, compare by year
}

void movie_print(const movie_struct *source) {
	printf("Title:    %s\n", source->title);
	printf("Year:     %d\n", source->year);
	printf("Director: %s\n", source->director);
	printf("Genre:    %s\n", GENRES[source->genre]);
	printf("Rating:   %.1f\n", source->rating);
}

char* movie_key(char *str, size_t max_length, movie_struct *source) {
	snprintf(str, max_length, "%s: %d", source->title, source->year);
	return str;
}

void genres_menu() {
	printf("Genres\n");
	for (int i = 0; i < GENRES_COUNT; i++) {
		printf(" %d: %s\n", i, GENRES[i]);
	}
}

